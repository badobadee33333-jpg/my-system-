# OpenScope OSINT Website

A beginner-friendly starter project with:
- Frontend: HTML, CSS, JavaScript
- Backend: Python + FastAPI
- Domain lookup: system DNS resolution
- IP lookup: address validation and reverse DNS
- URL threat check: optional existing-report lookup using VirusTotal API
- Database schema: MySQL tables for users, search history, reports, and audit logs

## 1. Requirements

Install Python 3.10 or newer. To run the SQL schema, install MySQL or XAMPP.

## 2. Start the backend

Open a terminal in the `osint-website` folder, then run:

### Windows
```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r backend\requirements.txt
```

Copy the root `.env` file and add your VirusTotal API key if you have one. Then start the API:

```powershell
cd backend
py -m uvicorn main:app --reload
```

API docs: http://127.0.0.1:8000/docs

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
cd backend
uvicorn main:app --reload
```

The code reads environment variables from the process. To load `.env` automatically, run from the project root with `python-dotenv` or add `from dotenv import load_dotenv; load_dotenv()` near the top of `backend/main.py`. Recommended: add these two lines to `backend/main.py` before app setup:
```python
from dotenv import load_dotenv
load_dotenv()
```
Then restart the server.

## 3. Open the frontend

Keep the backend running. In VS Code, open `frontend/index.html` and select **Open with Live Server**. The frontend calls `http://127.0.0.1:8000`.

If the browser blocks a request, check the backend terminal and make sure the API is running.

## 4. Set up the database (optional for this starter)

1. Start MySQL in XAMPP.
2. Open phpMyAdmin at http://localhost/phpmyadmin.
3. Select the SQL tab and run the contents of `database/schema.sql`.

Note: the current API endpoints do not yet write users or searches to MySQL. The schema is a starting point for adding authentication and saved history.

## 5. VirusTotal API

Put your key in `.env`:
```env
VIRUSTOTAL_API_KEY=your_key_here
```
Then add dotenv loading as described above and restart the backend. The threat endpoint only requests an existing URL report; it does not submit URLs for scanning. Follow VirusTotal's terms, quotas, and privacy rules.

## Important notes

- This is a learning starter, not a production-ready security platform.
- Do not expose API keys in frontend code or commit `.env`.
- Before deployment, restrict CORS to your real frontend domain, add authentication/rate limiting, validate all inputs, and protect stored data.
- Only use OSINT tools for lawful, authorized research. Public IP estimates and automated threat detections can be inaccurate.
