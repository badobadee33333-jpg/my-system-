from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, HttpUrl
from services.domain_lookup import lookup_domain
from services.ip_lookup import lookup_ip
from services.threat_intel import check_url

app = FastAPI(
    title="OpenScope OSINT API",
    description="Starter API for responsible public-source domain, IP, and URL checks.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict to your frontend origin before production deployment.
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

class LookupRequest(BaseModel):
    target: str = Field(min_length=1, max_length=2048)

@app.get("/")
def root():
    return {"name": "OpenScope OSINT API", "status": "online", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.post("/api/domain")
def domain_endpoint(request: LookupRequest):
    try:
        return lookup_domain(request.target.strip())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception:
        raise HTTPException(status_code=502, detail="Domain lookup failed. Check the domain and try again.")

@app.post("/api/ip")
def ip_endpoint(request: LookupRequest):
    try:
        return lookup_ip(request.target.strip())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception:
        raise HTTPException(status_code=502, detail="IP lookup failed.")

@app.post("/api/threat")
def threat_endpoint(request: LookupRequest):
    try:
        return check_url(request.target.strip())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception:
        raise HTTPException(status_code=502, detail="Threat check failed.")
