import socket
import re

DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$")

def lookup_domain(domain: str) -> dict:
    domain = domain.strip().rstrip(".")
    if "://" in domain or "/" in domain or not DOMAIN_RE.fullmatch(domain):
        raise ValueError("Enter a valid domain name, for example example.com.")
    try:
        records = sorted({item[4][0] for item in socket.getaddrinfo(domain, None)})
    except socket.gaierror:
        raise ValueError("The domain could not be resolved. Check the spelling or DNS status.")
    return {
        "target": domain,
        "resolved_ip_addresses": records,
        "record_note": "This starter performs DNS address resolution only; it does not yet query WHOIS, MX, TXT, or certificate-transparency sources.",
        "source": "System DNS resolver",
    }
