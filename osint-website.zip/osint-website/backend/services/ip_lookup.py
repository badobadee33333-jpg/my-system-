import ipaddress
import socket

def lookup_ip(value: str) -> dict:
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        raise ValueError("Enter a valid IPv4 or IPv6 address.")
    if not address.is_global:
        return {
            "target": str(address),
            "version": f"IPv{address.version}",
            "is_global": False,
            "classification": "Private, loopback, reserved, or otherwise non-global address",
            "note": "Public geolocation and reputation lookups are not performed for non-global addresses.",
        }
    try:
        reverse_name = socket.gethostbyaddr(str(address))[0]
    except (socket.herror, socket.gaierror, OSError):
        reverse_name = "No reverse DNS name found"
    return {
        "target": str(address),
        "version": f"IPv{address.version}",
        "is_global": True,
        "reverse_dns": reverse_name,
        "note": "Reverse DNS is not the same as geolocation or proof of ownership.",
        "source": "System reverse DNS resolver",
    }
