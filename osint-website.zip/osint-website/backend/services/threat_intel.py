import os
from urllib.parse import urlparse
import httpx

def check_url(value: str) -> dict:
    parsed = urlparse(value)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Enter a complete URL beginning with https:// or http://.")
    api_key = os.getenv("VIRUSTOTAL_API_KEY", "").strip()
    if not api_key:
        return {
            "target": value,
            "status": "API key not configured",
            "message": "Set VIRUSTOTAL_API_KEY in the backend .env file to enable VirusTotal URL reports.",
            "safety_note": "No verdict was obtained. This is not a declaration that the URL is safe.",
        }
    # VirusTotal URL reports require URL-safe base64 identifiers. This endpoint requests a report
    # for the submitted URL identifier; it does not submit the URL for scanning.
    import base64
    url_id = base64.urlsafe_b64encode(value.encode()).decode().rstrip("=")
    headers = {"x-apikey": api_key}
    try:
        response = httpx.get(
            f"https://www.virustotal.com/api/v3/urls/{url_id}",
            headers=headers,
            timeout=15.0,
        )
    except httpx.HTTPError:
        raise RuntimeError("Could not connect to VirusTotal.")
    if response.status_code == 404:
        return {
            "target": value,
            "status": "No existing report",
            "message": "VirusTotal has no existing URL report for this identifier.",
            "safety_note": "No existing report does not mean the URL is safe.",
        }
    if response.status_code == 401:
        raise ValueError("VirusTotal rejected the API key. Check VIRUSTOTAL_API_KEY.")
    if response.status_code == 429:
        raise ValueError("VirusTotal rate limit reached. Try again later.")
    response.raise_for_status()
    payload = response.json().get("data", {}).get("attributes", {})
    stats = payload.get("last_analysis_stats", {})
    return {
        "target": value,
        "status": "Existing VirusTotal report found",
        "analysis_stats": stats,
        "last_analysis_date_unix": payload.get("last_analysis_date"),
        "reputation": payload.get("reputation"),
        "source": "VirusTotal API",
        "safety_note": "Automated detections can be wrong or incomplete; review the source report and context.",
    }
