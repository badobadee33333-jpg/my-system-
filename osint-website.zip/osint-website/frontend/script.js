const API_BASE = "http://127.0.0.1:8000";
const tools = {
  domain: {title:"Domain intelligence", badge:"DNS", label:"Domain name", placeholder:"example.com", hint:"Enter a domain such as example.com. Do not include https://", endpoint:"/api/domain"},
  ip: {title:"IP intelligence", badge:"IP", label:"Public IP address", placeholder:"8.8.8.8", hint:"Enter a public IPv4 or IPv6 address.", endpoint:"/api/ip"},
  threat: {title:"URL threat check", badge:"THREAT", label:"Website URL", placeholder:"https://example.com", hint:"Enter a complete URL. VirusTotal API key is optional and configured on the backend.", endpoint:"/api/threat"}
};
let selectedTool = "domain";
const form = document.querySelector("#lookupForm");
const input = document.querySelector("#targetInput");
const submitBtn = document.querySelector("#submitBtn");
const message = document.querySelector("#message");
const results = document.querySelector("#results");

function selectTool(name) {
  selectedTool = name;
  const tool = tools[name];
  document.querySelectorAll(".nav-item").forEach(btn => btn.classList.toggle("active", btn.dataset.tool === name));
  document.querySelector("#toolTitle").textContent = tool.title;
  document.querySelector("#toolBadge").textContent = tool.badge;
  document.querySelector("#targetLabel").textContent = tool.label;
  document.querySelector("#inputHint").textContent = tool.hint;
  input.placeholder = tool.placeholder;
  input.value = "";
  message.hidden = true;
  input.focus();
}
document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => selectTool(btn.dataset.tool)));
document.querySelector("#clearBtn").addEventListener("click", () => {
  results.innerHTML = '<div class="empty-state"><div class="empty-icon">⌕</div><h3>Ready when you are</h3><p>Run a lookup to see results here.</p></div>';
  message.hidden = true;
});

function showMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? "message error" : "message";
  message.hidden = false;
}
function prettyKey(key) {
  return key.replaceAll("_", " ").replace(/\b\w/g, char => char.toUpperCase());
}
function renderResults(data) {
  results.innerHTML = "";
  Object.entries(data).forEach(([key, value]) => {
    if (key === "success") return;
    const card = document.createElement("article");
    card.className = "result-card";
    const title = document.createElement("h3");
    title.textContent = prettyKey(key);
    const content = document.createElement("div");
    content.className = "result-value";
    content.textContent = typeof value === "object" && value !== null ? JSON.stringify(value, null, 2) : String(value ?? "No data");
    card.append(title, content);
    results.appendChild(card);
  });
  if (!results.children.length) results.innerHTML = '<div class="empty-state"><h3>No results</h3><p>The service returned no fields.</p></div>';
}
form.addEventListener("submit", async event => {
  event.preventDefault();
  const target = input.value.trim();
  if (!target) return;
  submitBtn.disabled = true;
  submitBtn.textContent = "Working…";
  message.hidden = true;
  try {
    const response = await fetch(`${API_BASE}${tools[selectedTool].endpoint}`, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({target})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Lookup failed. Check the target and backend.");
    renderResults(data);
    showMessage("Lookup completed. Confirm findings against the source before relying on them.");
  } catch (error) {
    showMessage(`${error.message}. Make sure the FastAPI backend is running at ${API_BASE}.`, true);
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = 'Run lookup <span>→</span>';
  }
});
